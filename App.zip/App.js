import { useEffect, useState } from "react";
//import Operation from "./Operation";

function App() {
  const [time, setTime] = useState(0)
  //const [store, setstore] = useState([])
var timer;

function keyDown(e){
  if(e.key === 'Enter'){
    clearInterval(timer);
    if(e.target.value !== Number && e.target.value > 0){
      setTime((prev)=> parseInt(e.target.value));
    }else{
      setTime(0)
    }
  }
}
useEffect(()=>{
  if(time>0){
    timer = setInterval(()=>{
      setTime((prev) => prev -1 );
      clearInterval(timer)
    }, 1000)
  }

},[time])


  return (
    <div className="App">
      <label >CountDown</label>
      <input onChange={(event)=> {setTime(event.target.value)}} value={time} type="number"/>
      <h2>{time}</h2>
      <button onClick={keyDown}>button</button>
      {/*<Operation value={time} updateTime = {setTime}/>*/}
    </div>
  );
}

export default App;
